# StoryMotion AI v3 — Ready for Railway

Prototype AI short-film generator dengan:
- Real moving animation (Google Veo 3.1)
- Firebase Auth (opsional)
- Credits + Midtrans payment (opsional)
- Persistent projects (SQLite)
- Auto subtitles (SRT)

---

## Deploy ke Railway (Recommended)

### 1. Siapkan akun
- Buat akun gratis di [railway.app](https://railway.app)
- Login dengan GitHub (disarankan)

### 2. Deploy project
**Cara A – Drag & Drop (paling cepat)**
1. Zip semua file di folder ini (kecuali `.venv` kalau ada)
2. Di Railway dashboard → **New Project** → **Deploy from local files** / atau connect GitHub
3. Upload ZIP atau folder

**Cara B – Dari GitHub (lebih bagus)**
1. Push folder ini ke repo GitHub
2. Di Railway → New Project → Deploy from GitHub repo
3. Pilih repo-nya

### 3. Set Environment Variables
Di Railway → project kamu → **Variables** tab, tambahkan:

| Variable            | Value                          | Wajib? |
|---------------------|--------------------------------|--------|
| `GEMINI_API_KEY`    | API key dari Google AI Studio  | **Ya** |
| `APP_BASE_URL`      | `https://xxx.up.railway.app`   | Ya (setelah dapat domain) |
| `FREE_CREDITS`      | `60`                           | Tidak  |
| `MIDTRANS_SERVER_KEY` | (opsional)                   | Tidak  |
| `MIDTRANS_CLIENT_KEY` | (opsional)                   | Tidak  |
| `MIDTRANS_IS_PRODUCTION` | `false`                    | Tidak  |

> Dapatkan `GEMINI_API_KEY` di: https://aistudio.google.com/apikey

### 4. Persistent Storage (penting!)
Agar project & video tidak hilang saat restart:
1. Di Railway → project → **Settings** atau **Volumes**
2. Tambah Volume
3. Mount path: `/app/data`  (untuk database)
4. Boleh tambah volume kedua untuk `/app/outputs` (video hasil generate)

### 5. Deploy & Coba
- Railway otomatis build pakai Dockerfile (sudah include FFmpeg)
- Setelah status **Success**, klik domain yang diberikan
- Buka situs → tulis ide cerita → Generate

---

## Cara Dapat Google Gemini / Veo API Key
1. Buka https://aistudio.google.com/
2. Login akun Google
3. Klik **Get API key** → Create API key
4. Copy key-nya ke Variable `GEMINI_API_KEY` di Railway

---

## Local Development

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# isi GEMINI_API_KEY di .env
uvicorn app:app --reload
```

Buka http://127.0.0.1:8000

**Syarat lokal:** FFmpeg harus terinstall di sistem (`ffmpeg -version`).

---

## Firebase Auth (Opsional)
1. Copy `static/firebase-config.example.js` → `static/firebase-config.js`
2. Isi config dari Firebase Console
3. Enable Google + Email/Password provider

---

## Midtrans Payment (Opsional)
Isi `MIDTRANS_SERVER_KEY` dan `MIDTRANS_CLIENT_KEY` di Variables Railway.

---

## Catatan Produksi
Sebelum dipakai serius:
- Ganti SQLite → PostgreSQL (Railway punya plugin Postgres)
- Simpan video ke S3 / Cloudflare R2 / GCS
- Verifikasi Firebase ID token di server
- Verifikasi signature Midtrans
- Tambah rate limit & moderation
